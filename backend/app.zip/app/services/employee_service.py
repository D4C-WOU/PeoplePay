from datetime import date

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.employee import Employee


def get_employee(db: Session, employee_id: int):
    employee = db.get(Employee, employee_id)

    if not employee:
        raise ValueError("Employee not found")

    return employee


def list_employees(
    db: Session,
    department_id: int | None = None,
    status=None,
):
    stmt = select(Employee)

    if department_id is not None:
        stmt = stmt.where(Employee.department_id == department_id)

    if status is not None:
        stmt = stmt.where(Employee.status == status)

    stmt = stmt.order_by(Employee.id)

    return list(db.scalars(stmt).all())


def create_employee(
    db: Session,
    employee_data,
):
    employee = Employee(**employee_data.model_dump())

    db.add(employee)

    try:
        db.commit()
        db.refresh(employee)
    except IntegrityError:
        db.rollback()
        raise ValueError(
            "Employee could not be created. "
            "Employee number or email may already exist."
        )

    return employee


def update_employee(
    db: Session,
    employee: Employee,
    employee_data,
):
    updates = employee_data.model_dump(exclude_unset=True)

    # ---------------------------------------------------------
    # Handle termination explicitly
    # ---------------------------------------------------------
    if "status" in updates:
        new_status = updates["status"]

        # If employee is being terminated, always set a
        # termination date if one doesn't already exist.
        if str(new_status).upper() == "TERMINATED":
            employee.status = new_status

            if employee.termination_date is None:
                employee.termination_date = date.today()

            # Do not allow a terminated employee to have
            # an active status later in this function.
            updates.pop("status", None)

        else:
            employee.status = new_status
            updates.pop("status", None)

    # ---------------------------------------------------------
    # Apply remaining updates
    # ---------------------------------------------------------
    for field, value in updates.items():
        setattr(employee, field, value)

    # ---------------------------------------------------------
    # Final consistency check
    # ---------------------------------------------------------
    if str(employee.status).upper() == "TERMINATED":
        if employee.termination_date is None:
            employee.termination_date = date.today()

    try:
        db.commit()
        db.refresh(employee)
    except IntegrityError:
        db.rollback()
        raise ValueError(
            "Employee could not be updated. "
            "Email or another unique field may already exist."
        )

    return employee


def terminate_employee(
    db: Session,
    employee: Employee,
):
    """
    Soft-delete / terminate an employee.

    The employee is NOT physically deleted from the database.
    Instead:
        status -> TERMINATED
        termination_date -> today

    This preserves historical payroll, attendance and contract data.
    """

    if str(employee.status).upper() == "TERMINATED":
        return employee

    employee.status = "TERMINATED"
    employee.termination_date = date.today()

    try:
        db.commit()
        db.refresh(employee)
    except IntegrityError:
        db.rollback()
        raise ValueError("Employee could not be terminated")

    return employee